package com.cg.walletapp.bean;

import java.time.LocalDateTime;
import java.util.TreeMap;

public class Customer {
	
	private String mobileNo;
	private String name;
	private String password;
	private String emailId;
	private Wallet wallet ;
	
	private  TreeMap<LocalDateTime, String> transact ;
	public Customer() {
		wallet = new Wallet();
		transact = new TreeMap<LocalDateTime, String>();
	}
	



	public Customer(String mobileNo, String name, String password, String emailId, Wallet wallet,
			TreeMap<LocalDateTime, String> transact) {
		super();
		this.mobileNo = mobileNo;
		this.name = name;
		this.password = password;
		this.emailId = emailId;
		this.wallet = wallet;
		this.transact = transact;
	}




	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this. mobileNo = mobileNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public TreeMap<LocalDateTime, String> getTransact() {
		return transact;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Wallet getWallet() {
		return wallet;
	}

	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}

	
	

}
