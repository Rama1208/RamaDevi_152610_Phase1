package com.cg.walletapp.repo;

import java.util.TreeMap;

import com.cg.walletapp.bean.Customer;

public interface WalletRepo {


	TreeMap<String, Customer> getDetails();

	String addCustomer(Customer customer);


}
