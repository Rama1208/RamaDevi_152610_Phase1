package com.cg.walletapp.exception;

public interface IWalletException {

	String nameException ="Enter Name Correctly";
	String mobileNumberException = "Enter  Mobile Number  Correctly";
	String passwordException ="Enter Password  Correctly";
	String emailIdException = " enter email id  Correctly";
	String invalidDetails = "Given details are incorrect ";
	String insufficientFunds = "Insufficient account balance";
	String ACCOUNTEXISTS = "Account already exists with the given mobile number";
}
